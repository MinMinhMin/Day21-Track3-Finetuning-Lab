# Hồ sơ nộp Lab 21 — Vũ Đức Minh, 2A202602895

## Trạng thái sau lượt bổ sung

Inference bổ sung ngày 08/10/2026 đã hoàn thành trên Kaggle T4. Đã lưu cả output
baseline (b) và FT `correct` của 50 target + 15 regression trong
`results/report_examples.json`. Điểm replay khớp điểm run gốc khi làm tròn bốn chữ số.

- [x] Họ tên và MSSV đúng thông tin người học cung cấp.
- [x] Đầy đủ mask proof, template check, token stats và baseline đóng băng.
- [x] Bốn run có cùng 30 optimizer update; attention-only khớp ngân sách <5%.
- [x] Report có ≥5 đối chiếu đầy đủ, gồm 3 ca thắng và 2 ca thua baseline.
- [x] Bốn nhóm metric, bốn run, verdict và kết luận ≥150 từ được trình bày.
- [x] Giữ nguyên verdict FAILED vì regression; không đổi tolerance.
- [x] Checksum adapter, dữ liệu và kết quả gốc khớp trước lượt bổ sung.
- [x] `python scripts/verify.py`: 28 PASS, 1 WARN về verdict FAILED, 0 FAIL.
- [x] 156 unit test đạt trên CPU; 2 test cần CUDA được bỏ qua khi kiểm tra local.
- [x] Đã bổ sung `HARDWARE-GUIDE.md` để ZIP giải nén chạy được test cấu trúc.
- [ ] Người học đọc lại report và phần phản tư trước khi gửi bài.
- [ ] Người học nộp ZIP cuối theo kênh quy định của lớp.

## Bằng chứng định tính

Toàn bộ target: 35 ca FT thắng, 15 ca hòa, 0 ca thua.
Toàn bộ regression: 1 ca FT thắng, 6 ca hòa, 8 ca thua.
Hai lỗi FT trên target[32]/target[44] hòa baseline ở điểm 0,75, nên ca thua trong
report được chọn từ regression[1] và regression[7]. Đây là kết quả thật được chấm
lại từ output, không thay đổi nhãn hoặc dựng thêm câu trả lời.

## Đóng gói và nộp

Chọn Option A: `lab21_2A202602895.zip`, chứa report/reflection, toàn bộ results,
adapter correct, notebook đã clear output, source/tests/data/requirements và manifest SHA256.
Không nộp gói có hậu tố DRAFT. ZIP cuối khoảng 115 MiB vì adapter thực tế khoảng 124 MiB.

Nếu cần đóng gói lại từ thư mục này, dùng lệnh dưới; output đầy đủ đã có sẵn:

```bash
python scripts/complete_submission.py --name "Vũ Đức Minh" --student-id "2A202602895" --package
```

`submission/evidence/kaggle_package_manifest.json` và `REPORT.kaggle.md` giữ bản
manifest/report nhận từ Kaggle trước khi bổ sung tài liệu và diễn giải cuối.
Notebook/log NB1–NB5 được giữ trong `submission/evidence/`. Manifest trong ZIP cuối
phản ánh các file của gói cuối, còn SHA của kết quả/adapter gốc nằm trong
`results/report_examples.json`.

Verdict FAILED vẫn được chấm đầy đủ theo rubric. Không nhận điểm thưởng B1–B5 khi
chưa có bằng chứng. Chưa gửi LMS, push GitHub hoặc publish adapter tự động.
