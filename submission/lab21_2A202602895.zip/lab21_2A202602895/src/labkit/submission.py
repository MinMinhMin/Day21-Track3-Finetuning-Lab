"""Compare full outputs against the frozen lab tasks, without loading a model."""
from __future__ import annotations

import json
import math
import re

from . import evaluate as ev


def _score(group, prediction, reference):
    return (ev.triage_field_accuracy(prediction, reference) if group == "target"
            else ev.keyword_recall(prediction, reference))


def build_examples(targets, regression, baseline_target, ft_target, baseline_regression, ft_regression):
    rows = []
    for group, dataset, baseline, tuned in [
        ("target", targets, baseline_target, ft_target),
        ("regression", regression, baseline_regression, ft_regression),
    ]:
        if not len(dataset) == len(baseline) == len(tuned):
            raise ValueError(f"{group}: prediction length does not match dataset length")
        for i, (ref, b, ft) in enumerate(zip(dataset, baseline, tuned)):
            reference = ref["label"] if group == "target" else ref["keywords"]
            sb, sf = _score(group, b, reference), _score(group, ft, reference)
            rows.append({"group": group, "i": i,
                         "prompt": ref["input"] if group == "target" else ref["instruction"],
                         "reference": reference, "baseline_pred": b, "ft_pred": ft,
                         "baseline_score": sb, "ft_score": sf,
                         "outcome": "win" if sf > sb else "loss" if sf < sb else "tie"})
    return rows


def select_examples(rows):
    # Prefer losses on the target task, then show regression failures if necessary.
    losses = sorted((r for r in rows if r["ft_score"] < r["baseline_score"]),
                    key=lambda r: (r["group"] != "target", r["ft_score"] - r["baseline_score"], r["i"]))
    if len(losses) < 2:
        raise ValueError("At least two genuine FT losses against baseline are required")
    chosen = losses[:2]
    wins = sorted((r for r in rows if r["group"] == "target" and r["ft_score"] > r["baseline_score"]),
                  key=lambda r: (r["baseline_score"] - r["ft_score"], r["i"]))
    for r in wins + rows:
        if not any((x["group"], x["i"]) == (r["group"], r["i"]) for x in chosen):
            chosen.append(r)
        if len(chosen) >= 5:
            return chosen[2:] + chosen[:2]
    raise ValueError("At least five distinct examples are required")


def validate_examples(rows, targets, regression):
    errors = []
    if not isinstance(rows, list) or len(rows) < 5:
        return ["At least five full baseline/FT comparisons are required"]
    seen = set()
    losses = 0
    for row in rows:
        try:
            group, i = row["group"], row["i"]
            if group not in {"target", "regression"} or type(i) is not int or i < 0:
                raise ValueError("invalid group/index")
            dataset = targets if group == "target" else regression
            ref = dataset[i]
            reference = ref["label"] if group == "target" else ref["keywords"]
            prompt = ref["input"] if group == "target" else ref["instruction"]
            if row["reference"] != reference or row["prompt"] != prompt:
                errors.append(f"{group}[{i}]: evidence does not match frozen dataset")
            if (group, i) in seen:
                errors.append(f"{group}[{i}]: duplicate example")
            seen.add((group, i))
            for key in ("baseline_pred", "ft_pred"):
                if not isinstance(row[key], str):
                    raise ValueError(f"missing full {key}")
            sb = _score(group, row["baseline_pred"], reference)
            sf = _score(group, row["ft_pred"], reference)
            for key, actual in [("baseline_score", sb), ("ft_score", sf)]:
                got = float(row[key])
                if not math.isfinite(got) or abs(got - actual) > 1e-9:
                    errors.append(f"{group}[{i}]: {key} disagrees with output score")
            if sf < sb:
                losses += 1
        except (KeyError, IndexError, TypeError, ValueError) as exc:
            errors.append(f"Malformed evidence: {exc}")
    if len(seen) < 5:
        errors.append("At least five distinct examples are required")
    if losses < 2:
        errors.append("At least two genuine FT losses against baseline are required")
    return errors


def _block(text):
    longest = max((len(x) for x in re.findall(r"`+", text)), default=0)
    fence = "`" * max(3, longest + 1)
    return f"{fence}text\n{text}\n{fence}"


def _comment(row):
    delta = row['ft_score'] - row['baseline_score']
    detail = f"Chênh điểm FT − baseline là {delta:+.4f}. "
    if row['group'] == 'target':
        def wrong(pred):
            return [key for key in row['reference']
                    if ev.triage_field_accuracy(pred, row['reference'], keys=[key]) == 0]
        b_wrong, ft_wrong = wrong(row['baseline_pred']), wrong(row['ft_pred'])
        detail += (f"Trường baseline sai/không chấm được: {', '.join(b_wrong) or 'không có'}; "
                   f"trường FT sai/không chấm được: {', '.join(ft_wrong) or 'không có'}. "
                   "Điểm này đo các trường theo nhãn corpus, không thay thế kiểm tra ticket thực tế.")
    else:
        def missing(pred):
            return [key for key in row['reference'] if ev.normalize(key) not in ev.normalize(pred)]
        b_missing, ft_missing = missing(row['baseline_pred']), missing(row['ft_pred'])
        detail += (f"Từ khóa baseline thiếu: {', '.join(b_missing) or 'không có'}; "
                   f"FT thiếu: {', '.join(ft_missing) or 'không có'}. "
                   "Đây là keyword recall; cần đọc output đầy đủ vì scorer không đánh giá "
                   "mọi diễn đạt tương đương hoặc sự mâu thuẫn trong câu trả lời.")
    return detail


def render_examples(rows):
    sections = ["Các ví dụ dưới đây được sinh bổ sung bằng cùng model/adapter và prompt; "
                "chỉ số tổng hợp của run gốc vẫn giữ nguyên. `i` là chỉ số bắt đầu từ 0."]
    names = {"win": "FT thắng", "loss": "FT thua baseline", "tie": "Hòa"}
    for n, row in enumerate(rows, 1):
        reference = json.dumps(row["reference"], ensure_ascii=False)
        sb, sf = row["baseline_score"], row["ft_score"]
        outcome = "win" if sf > sb else "loss" if sf < sb else "tie"
        sections.append(f"### Ví dụ {n} — {row['group']}[{row['i']}] — {names[outcome]}\n\n"
                        f"**Đầu vào:** {row['prompt']}\n\n**Nhãn/từ khóa chấm:** `{reference}`\n\n"
                        f"**Baseline (b), điểm {sb:.4f}:**\n\n{_block(row['baseline_pred'])}\n\n"
                        f"**Fine-tune, điểm {sf:.4f}:**\n\n{_block(row['ft_pred'])}\n\n"
                        f"**Nhận xét theo scorer:** {_comment(row)}")
    return "\n\n".join(sections)
