#!/usr/bin/env python3
"""Collect full qualitative outputs, finalize the report, and build the lab ZIP.

Does inference only. The frozen baselines, verdict and trained adapters are read-only.
Run on Kaggle with --collect; --draft produces an explicitly incomplete review ZIP.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError, version
import zipfile

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))
BEGIN = "<!-- QUALITATIVE_BEGIN -->"
END = "<!-- QUALITATIVE_END -->"


def read_jsonl(path):
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect(root):
    import torch
    from peft import PeftModel
    from labkit import generate, submission, device
    from labkit.config import get_tier

    if not torch.cuda.is_available():
        raise RuntimeError("Collect on the Kaggle GPU session containing your saved correct adapter.")
    frozen = json.loads((root / "results/baselines_frozen.json").read_text())
    verdict = json.loads((root / "results/verdict.json").read_text())
    targets = read_jsonl(root / "data/eval_target.jsonl")
    regression = read_jsonl(root / "data/eval_regression.jsonl")
    if frozen.get("smoke_mode") or (len(targets), len(regression)) != (
            frozen["n_target"], frozen["n_regression"]):
        raise ValueError("Full frozen evaluation sets are required.")
    tier = get_tier(frozen["tier"])
    if tier.model_id != frozen["model"]:
        raise ValueError("BASE_MODEL differs from the frozen model; remove the override.")
    if hashlib.sha256(generate.OPTIMIZED_PROMPT.encode()).hexdigest()[:16] != frozen["optimized_prompt_sha"]:
        raise ValueError("Optimized prompt differs from the frozen baseline.")
    watched = [root / "results" / f for f in
               ["baselines_frozen.json", "verdict.json", "autopsy.json", "runs.csv"]]
    watched += [root / "data/eval_target.jsonl", root / "data/eval_regression.jsonl",
                root / "adapters/correct/adapter_model.safetensors",
                root / "adapters/correct/adapter_config.json"]
    before = {str(p.relative_to(root)): sha(p) for p in watched}
    refs = json.loads((root / "data/checksums.json").read_text())
    for name in ("eval_target.jsonl", "eval_regression.jsonl"):
        if sha(root / "data" / name)[:16] != refs[name]:
            raise ValueError(f"Frozen dataset changed: {name}")
    model, tok = generate.load_base(tier)
    model.eval()
    b_target, _ = generate.generate_batch(model, tok, [r["input"] for r in targets],
                                          system=generate.OPTIMIZED_PROMPT, label="report/b/target")
    b_reg, _ = generate.generate_batch(model, tok, [r["instruction"] for r in regression],
                                       system=None, max_new_tokens=96, label="report/b/regression")
    model = PeftModel.from_pretrained(model, str(root / "adapters/correct"))
    model.eval()
    ft_target, _ = generate.generate_batch(model, tok, [r["input"] for r in targets],
                                           system=generate.NAIVE_PROMPT, label="report/ft/target")
    ft_reg, _ = generate.generate_batch(model, tok, [r["instruction"] for r in regression],
                                        system=None, max_new_tokens=96, label="report/ft/regression")
    del model
    generate.free_memory()
    rows = submission.build_examples(targets, regression, b_target, ft_target, b_reg, ft_reg)
    measured = {}
    for group in ("target", "regression"):
        group_rows = [r for r in rows if r["group"] == group]
        for role, field in [("baseline_b", "baseline_score"), ("fine_tune", "ft_score")]:
            measured.setdefault(role, {})[group] = sum(r[field] for r in group_rows) / len(group_rows)
    ft_original = next(x for x in verdict["comparison"] if x["run"] == "(c) LoRA fine-tune")
    matched = all(round(measured[role][group], 4) == round(original[group], 4)
                  for role, original in [("baseline_b", frozen["baseline_b"]), ("fine_tune", ft_original)]
                  for group in ("target", "regression"))
    versions = {}
    for package in ("torch", "transformers", "trl", "peft", "accelerate", "bitsandbytes", "tokenizers"):
        try:
            versions[package] = version(package)
        except PackageNotFoundError:
            versions[package] = "not installed"
    payload = {"created_at": datetime.now(timezone.utc).isoformat(),
               "purpose": "supplementary qualitative inference; original scores unchanged",
               "model": tier.model_id, "device": device.describe(), "versions": versions,
               "decoding": {"do_sample": False, "batch_size": 4, "enable_thinking": False,
                            "target_max_new_tokens": 160, "regression_max_new_tokens": 96},
               "original_artifact_sha256": before, "replay_scores": measured,
               "replay_matches_original": matched, "all_examples": rows, "selected": []}
    for rel, digest in before.items():
        if sha(root / rel) != digest:
            raise RuntimeError(f"Original artifact changed during inference: {rel}")
    try:
        payload["selected"] = submission.select_examples(rows)
    finally:
        # Keep all real outputs even when no pair of genuine losses was found.
        (root / "results/report_examples.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return payload


def update_report(root, payload=None, name=None, student_id=None):
    from labkit import submission
    path = root / "submission/REPORT.md"
    text = path.read_text(encoding="utf-8")
    for label, value in [("Họ tên", name), ("MSSV", student_id)]:
        if value:
            text = re.sub(rf"(?m)^\*\*{label}\*\*:.*$", lambda m: f"**{label}**: {value}", text)
    if payload is not None:
        if BEGIN not in text or END not in text:
            raise ValueError("Report has no qualitative section markers; use the completed report supplied with this script.")
        targets, regression = read_jsonl(root / "data/eval_target.jsonl"), read_jsonl(root / "data/eval_regression.jsonl")
        errors = submission.validate_examples(payload.get("selected", []), targets, regression)
        if errors:
            raise ValueError("; ".join(errors))
        body = submission.render_examples(payload["selected"])
        body += "\n\n**Nguồn:** `results/report_examples.json`, suy luận bổ sung tại " + payload["created_at"] + "."
        body += "\n\n**Đối chiếu replay:** " + ("Điểm target/regression khớp run gốc khi làm tròn 4 chữ số."
                  if payload.get("replay_matches_original") else
                  "Điểm replay khác run gốc: " + json.dumps(payload["replay_scores"], ensure_ascii=False)
                  + ". Đây là output của lượt bổ sung; các bảng kết quả gốc không bị thay thế.")
        text = text.split(BEGIN)[0] + BEGIN + "\n\n" + body + "\n\n" + END + text.split(END, 1)[1]
        text = re.sub(r"(?m)^\*\*Trạng thái định tính\*\*:.*$",
                      "**Trạng thái định tính**: Đã có ≥5 đối chiếu đầy đủ và ≥2 ca FT thua baseline.", text)
        text = text.replace("## 6. Định tính — bằng chứng có sẵn và đối chiếu cần hoàn tất",
                            "## 6. Định tính — đối chiếu baseline và fine-tune")
        text = text.replace("`results/report_examples.json` khi đã thu thập",
                            "`results/report_examples.json`")
    path.write_text(text, encoding="utf-8")


def package(root, output, label, *, draft=False):
    patterns = ["submission/*.md", "submission/figures/*", "submission/evidence/*",
                "results/*.json", "results/*.csv", "notebooks/*.py",
                "colab/*.ipynb", "src/labkit/*.py", "scripts/*.py", "tests/*.py",
                "data/*.json", "data/*.jsonl", "data/split/*.jsonl", "docs/*.md"]
    files = {p for pattern in patterns for p in root.glob(pattern) if p.is_file()}
    files |= {root / rel for rel in ["README.md", "HARDWARE-GUIDE.md", "rubric.md", "requirements.txt", "requirements-cpu.txt",
                                     "pyproject.toml", "Makefile", "LICENSE", "adapters/correct/adapter_config.json",
                                     "adapters/correct/adapter_model.safetensors"] if (root / rel).is_file()}
    files = {p for p in files if not any(part in {"__pycache__", ".git", ".cache"}
                                       for part in p.relative_to(root).parts)
             and p.name != ".env" and not p.name.startswith(".env.")
             and not p.name.endswith((".token", ".pyc", ".pyo"))}
    manifest = {"created_at": datetime.now(timezone.utc).isoformat(), "draft": draft,
                "files_sha256": {str(p.relative_to(root)): sha(p) for p in sorted(files)}}
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for p in sorted(files):
            arcname = f"{label}/{p.relative_to(root).as_posix()}"
            archive.write(p, arcname)
        archive.writestr(f"{label}/submission/ARTIFACT_MANIFEST.json",
                         json.dumps(manifest, ensure_ascii=False, indent=2))
    print(f"{'DRAFT' if draft else 'Submission'} ZIP: {output} ({output.stat().st_size / 1024**2:.1f} MiB)")


def identity_complete(report):
    for label in ("Họ tên", "MSSV"):
        match = re.search(rf"(?m)^\*\*{label}\*\*:[ \t]*([^\n]*)$", report)
        if match is None or not match.group(1).strip() or match.group(1).strip().startswith("Chưa"):
            return False
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=REPO_ROOT)
    parser.add_argument("--collect", action="store_true", help="Kaggle GPU: collect full b/FT outputs without training")
    parser.add_argument("--name")
    parser.add_argument("--student-id")
    parser.add_argument("--package", action="store_true")
    parser.add_argument("--draft", action="store_true", help="explicitly incomplete ZIP for review")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    sys.path.insert(0, str(root / "src"))
    if not (root / "results/verdict.json").is_file():
        parser.error(f"No completed results in {root}")
    payload = collect(root) if args.collect else None
    if payload is None and (root / "results/report_examples.json").is_file():
        payload = json.loads((root / "results/report_examples.json").read_text())
    update_report(root, payload, args.name, args.student_id)
    report = (root / "submission/REPORT.md").read_text(encoding="utf-8")
    identified = identity_complete(report)
    result = subprocess.run([sys.executable, str(root / "scripts/verify.py")], cwd=root)
    ready = result.returncode == 0 and identified
    if not identified:
        print("Họ tên/MSSV chưa được cung cấp; dùng --name và --student-id.")
    if args.package:
        if not ready and not args.draft:
            print("Not ready to submit. Use --draft only to create an explicitly incomplete review ZIP.")
            return 1
        tag = re.sub(r"[^A-Za-z0-9_-]", "_", args.student_id or "MinMinhMin")
        label = f"lab21_{tag}"
        output = args.output or root / "submission" / f"{label}{'_DRAFT' if not ready else ''}.zip"
        package(root, output, label, draft=not ready)
    return 0 if ready else 1


if __name__ == "__main__":
    raise SystemExit(main())
