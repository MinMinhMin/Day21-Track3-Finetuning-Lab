import copy

import pytest

from labkit import submission


@pytest.fixture
def evidence():
    label = {"intent": "doi_tra", "urgency": "cao", "product": "áo", "sentiment": "trung_tinh"}
    import json
    targets = [{"input": f"ticket {i}", "label": label} for i in range(3)]
    regression = [{"instruction": "1 km bằng bao nhiêu mét?", "keywords": ["1000"]},
                  {"instruction": "Thủ đô Việt Nam?", "keywords": ["Hà Nội"]}]
    rows = submission.build_examples(
        targets, regression, ["không có JSON"] * 3,
        [json.dumps(label, ensure_ascii=False)] * 3,
        ["1000 mét", "Hà Nội"], ["không biết", "không biết"])
    return targets, regression, rows


def test_examples_include_actual_wins_and_losses_with_full_outputs(evidence):
    targets, regression, rows = evidence
    chosen = submission.select_examples(rows)
    assert len(chosen) == 5
    assert sum(x["ft_score"] < x["baseline_score"] for x in chosen) == 2
    assert all(x["baseline_pred"] and x["ft_pred"] for x in chosen)
    assert submission.validate_examples(chosen, targets, regression) == []
    text = submission.render_examples(chosen)
    assert "1000 mét" in text and "Hà Nội" in text and "không biết" in text


def test_incomplete_prediction_lists_cannot_silently_truncate():
    with pytest.raises(ValueError, match="length"):
        submission.build_examples([{"input": "ticket", "label": {}}], [], [], [], [], [])


def test_wrong_answers_do_not_automatically_mean_losing_to_baseline():
    target = [{"input": "ticket", "label": {"intent": "doi_tra"}}] * 5
    rows = submission.build_examples(target, [], ["invalid"] * 5, ["invalid"] * 5, [], [])
    with pytest.raises(ValueError, match="two.*loss"):
        submission.select_examples(rows)


def test_tampered_scores_are_rejected(evidence):
    targets, regression, rows = evidence
    rows = copy.deepcopy(rows)
    rows[-1]["ft_score"] = 1.
    assert any("score" in e for e in submission.validate_examples(rows, targets, regression))


def test_evidence_must_match_frozen_questions_and_labels(evidence):
    targets, regression, rows = evidence
    rows = copy.deepcopy(rows)
    rows[0]["prompt"] = "another ticket"
    assert any("dataset" in e for e in submission.validate_examples(rows, targets, regression))


def test_missing_and_duplicate_evidence_does_not_pass(evidence):
    targets, regression, rows = evidence
    assert submission.validate_examples([], targets, regression)
    assert submission.validate_examples([rows[-1]] * 5, targets, regression)


def test_empty_generated_answer_is_a_real_loss_not_missing_evidence(evidence):
    targets, regression, rows = evidence
    rows = copy.deepcopy(rows)
    rows[-1]['ft_pred'] = ''
    assert submission.validate_examples(rows, targets, regression) == []


def test_report_explains_observed_field_and_keyword_errors(evidence):
    _, _, rows = evidence
    text = submission.render_examples(submission.select_examples(rows))
    assert '**Nhận xét theo scorer:**' in text
    assert 'intent' in text and 'urgency' in text
    assert 'FT thiếu: 1000' in text
    assert 'keyword recall' in text
