import importlib.util
import json
from pathlib import Path
import zipfile

import pytest


def script():
    path = Path(__file__).resolve().parents[1] / 'scripts/complete_submission.py'
    spec = importlib.util.spec_from_file_location('complete_submission', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_identity_cannot_pass_with_missing_name_or_student_id():
    mod = script()
    assert not mod.identity_complete('**Họ tên**: Chưa được cung cấp.\n**MSSV**: Chưa được cung cấp.')
    assert not mod.identity_complete('**Họ tên**: Vũ Đức Minh\n**MSSV**: ')
    assert mod.identity_complete('**Họ tên**: Vũ Đức Minh\n**MSSV**: 2A202602895')


def test_package_excludes_secrets_other_adapters_and_archive_itself(tmp_path):
    mod = script()
    for rel, data in {'submission/REPORT.md': 'report', 'results/verdict.json': '{}',
                      'Makefile': 'verify:\n\tpython scripts/verify.py\n',
                      'HARDWARE-GUIDE.md': 'Hardware documentation required by structural tests',
                      'adapters/correct/adapter_config.json': '{}',
                      'adapters/correct/adapter_model.safetensors': 'correct weights',
                      'adapters/qlora/adapter_model.safetensors': 'other weights',
                      '.env': 'HF_TOKEN=secret', 'src/labkit/__pycache__/test.pyc': 'cache'}.items():
        p=tmp_path/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
    output=tmp_path/'submission/lab21_DRAFT.zip'
    mod.package(tmp_path,output,'lab21_test',draft=True)
    with zipfile.ZipFile(output) as archive:
        names=archive.namelist()
        assert 'lab21_test/adapters/correct/adapter_model.safetensors' in names
        assert 'lab21_test/Makefile' in names
        assert 'lab21_test/HARDWARE-GUIDE.md' in names
        assert not any('.env' in n or '__pycache__' in n or 'qlora/' in n or n.endswith('.zip') for n in names)
        manifest=json.loads(archive.read('lab21_test/submission/ARTIFACT_MANIFEST.json'))
        assert manifest['draft'] is True
        assert manifest['files_sha256']['adapters/correct/adapter_model.safetensors']==mod.sha(tmp_path/'adapters/correct/adapter_model.safetensors')


def test_empty_name_before_valid_student_id_is_not_an_identity():
    assert not script().identity_complete('**Họ tên**: \n**MSSV**: 2A202602895')


def test_nested_env_is_excluded_from_submission_evidence(tmp_path):
    p=tmp_path/'submission/evidence/.env';p.parent.mkdir(parents=True);p.write_text('secret')
    output=tmp_path/'out.zip'
    script().package(tmp_path,output,'lab21_test',draft=True)
    with zipfile.ZipFile(output) as archive:
        assert not any(n.endswith('/.env') for n in archive.namelist())


def test_report_finalizer_replaces_pending_heading_and_full_examples(tmp_path):
    from labkit import submission
    targets = [{'input': f'ticket {i}', 'label': {'intent': 'doi_tra', 'urgency': 'cao',
                'product': 'áo', 'sentiment': 'trung_tinh'}} for i in range(3)]
    reg = [{'instruction': '1 km?', 'keywords': ['1000']},
           {'instruction': 'Thủ đô Việt Nam?', 'keywords': ['Hà Nội']}]
    rows = submission.build_examples(targets, reg, ['invalid'] * 3,
        [json.dumps(r['label']) for r in targets], ['1000', 'Hà Nội'], ['không biết'] * 2)
    (tmp_path/'data').mkdir()
    for name, items in [('eval_target', targets), ('eval_regression', reg)]:
        (tmp_path/f'data/{name}.jsonl').write_text('\n'.join(json.dumps(r) for r in items))
    (tmp_path/'submission').mkdir()
    report = tmp_path/'submission/REPORT.md'
    report.write_text('**Họ tên**: Chưa\n**MSSV**: Chưa\n**Trạng thái định tính**: Chưa\n'
        '## 6. Định tính — bằng chứng có sẵn và đối chiếu cần hoàn tất\n'
        '<!-- QUALITATIVE_BEGIN -->\nPending\n<!-- QUALITATIVE_END -->')
    payload = {'selected': submission.select_examples(rows), 'created_at': '2026-10-08',
               'replay_matches_original': True}
    script().update_report(tmp_path, payload, 'Vũ Đức Minh', '2A202602895')
    updated = report.read_text()
    assert 'Pending' not in updated and 'cần hoàn tất' not in updated
    assert updated.count('**Baseline (b), điểm') == 5
    assert 'Đã có ≥5' in updated and '2A202602895' in updated
